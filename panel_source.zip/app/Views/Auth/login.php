<?= $this->extend('Layout/Starter') ?>

<?= $this->section('css') ?>
<style>
    body {
        background: linear-gradient(135deg, #000000 0%, #0f172a 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
        overflow: hidden;
    }

    /* Splash Screen */
    #splash {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100vh;
        background: black;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        flex-direction: column;
        color: #00FF00;
        font-family: 'Courier New', monospace;
        overflow: hidden;
    }

    #matrix {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: black;
        color: #00FF00;
        font-size: 14px;
        opacity: 0.8;
    }

    #splash h1 {
        position: relative;
        z-index: 2;
        font-size: 1.5rem;
        margin-top: 30px;
        text-shadow: 0 0 10px #00ff00;
        animation: glow 1s ease-in-out infinite alternate;
    }

    @keyframes glow {
        from { text-shadow: 0 0 5px #00ff00; }
        to { text-shadow: 0 0 20px #00ff00; }
    }

    /* Login Page */
    .login-container {
        min-height: 100vh;
        display: none;
        align-items: center;
        justify-content: center;
        padding: 20px;
        animation: fadeIn 1s forwards;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .login-card {
        background: rgba(17, 24, 39, 0.9);
        border-radius: 20px;
        box-shadow: 0 20px 40px rgba(0,255,0,0.1);
        overflow: hidden;
        width: 100%;
        max-width: 400px;
        border: 1px solid #00ff00;
    }

    .login-header {
        background: linear-gradient(135deg, #00ff00 0%, #059669 100%);
        padding: 40px 30px;
        text-align: center;
        color: black;
    }

    .crown-icon {
        font-size: 3rem;
        margin-bottom: 15px;
        display: block;
    }

    .login-title {
        font-size: 1.5rem;
        font-weight: 700;
    }

    .login-subtitle {
        font-size: 0.9rem;
        color: black;
        opacity: 0.9;
    }

    .login-body {
        padding: 40px 30px;
    }

    .form-group {
        margin-bottom: 25px;
        position: relative;
    }

    .form-input {
        width: 100%;
        padding: 15px 20px 15px 50px;
        border: 2px solid #00ff00;
        border-radius: 12px;
        font-size: 1rem;
        background: #000;
        color: #00ff00;
        font-family: 'Courier New', monospace;
    }

    .form-input:focus {
        outline: none;
        border-color: #39ff14;
        box-shadow: 0 0 15px #00ff00;
    }

    .input-icon, .password-toggle {
        position: absolute;
        color: #00ff00;
    }

    .input-icon {
        left: 18px;
        top: 50%;
        transform: translateY(-50%);
    }

    .password-toggle {
        right: 18px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        cursor: pointer;
        font-size: 1.1rem;
    }

    .login-btn {
        width: 100%;
        background: #00ff00;
        color: black;
        border: none;
        padding: 15px;
        border-radius: 12px;
        font-size: 1rem;
        font-weight: 700;
        cursor: pointer;
        transition: 0.3s;
        font-family: 'Courier New', monospace;
    }

    .login-btn:hover {
        transform: scale(1.03);
        box-shadow: 0 0 20px #00ff00;
    }

    .register-link {
        text-align: center;
        margin-top: 25px;
        color: #00ff00;
        font-size: 0.9rem;
    }

    .register-link a {
        color: #39ff14;
        text-decoration: none;
        font-weight: 600;
    }

    .demo-credentials {
        background: #000;
        border-radius: 12px;
        border: 1px solid #00ff00;
        padding: 15px;
        margin-top: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 0.85rem;
        color: #00ff00;
        font-family: 'Courier New', monospace;
    }

    .error-message {
        color: #EF4444;
        font-size: 0.85rem;
        margin-top: 5px;
        display: block;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<!-- HACKING SPLASH SCREEN -->
<div id="splash">
    <canvas id="matrix"></canvas>
    <h1>Initializing YT-MURSLEEN VIP PANEL...</h1>
</div>

<!-- LOGIN PAGE -->
<div class="login-container" id="loginContainer">
    <div class="login-card">
        <div class="login-header">
            <i class="bi bi-cpu-fill crown-icon"></i>
            <h1 class="login-title">YT-MURSLEEN HACK PANEL</h1>
            <p class="login-subtitle">Access restricted. Authorized users only.</p>
        </div>
        <div class="login-body">
            <?= $this->include('Layout/msgStatus') ?>
            <?= form_open() ?>
            
            <div class="form-group">
                <i class="bi bi-person-fill input-icon"></i>
                <input type="text" class="form-input" name="username" id="username" placeholder="Enter ID" required>
            </div>

            <div class="form-group">
                <i class="bi bi-lock-fill input-icon"></i>
                <input type="password" class="form-input" name="password" id="password" placeholder="Access Key" required>
                <button type="button" class="password-toggle" onclick="togglePassword()">
                    <i class="bi bi-eye-fill" id="passwordToggleIcon"></i>
                </button>
            </div>

            <button type="submit" class="login-btn">LOGIN</button>
            
            <?= form_close() ?>

            <div class="register-link">
                Need Access? <a href="<?= site_url('register') ?>">Request Authorization</a>
            </div>

            <div class="demo-credentials">
                <i class="bi bi-terminal-fill"></i>
                <span>Contact Admin: @YtMursleen2</span>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    // MATRIX ANIMATION
    const canvas = document.getElementById("matrix");
    const ctx = canvas.getContext("2d");
    canvas.height = window.innerHeight;
    canvas.width = window.innerWidth;
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#$%^&*()*&^%".split("");
    const fontSize = 14;
    const columns = canvas.width / fontSize;
    const drops = Array(Math.floor(columns)).fill(1);

    function draw() {
        ctx.fillStyle = "rgba(0, 0, 0, 0.05)";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#00FF00";
        ctx.font = fontSize + "px monospace";
        for (let i = 0; i < drops.length; i++) {
            const text = letters[Math.floor(Math.random() * letters.length)];
            ctx.fillText(text, i * fontSize, drops[i] * fontSize);
            if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) drops[i] = 0;
            drops[i]++;
        }
    }
    setInterval(draw, 33);

    // SPLASH TO LOGIN TRANSITION
    window.addEventListener('load', () => {
        setTimeout(() => {
            document.getElementById("splash").style.display = "none";
            document.getElementById("loginContainer").style.display = "flex";
            document.body.style.overflow = "auto";
        }, 4000);
    });

    // PASSWORD TOGGLE
    function togglePassword() {
        const passwordInput = document.getElementById('password');
        const toggleIcon = document.getElementById('passwordToggleIcon');
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleIcon.className = 'bi bi-eye-slash-fill';
        } else {
            passwordInput.type = 'password';
            toggleIcon.className = 'bi bi-eye-fill';
        }
    }
</script>
<?= $this->endSection() ?>
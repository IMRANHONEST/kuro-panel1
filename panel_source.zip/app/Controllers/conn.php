<?php

$servername = "localhost";
$username = "httpsytmursleenp_YtMursleenPanel";
$password = "httpsytmursleenp_YtMursleenPanel";
$dbname = "httpsytmursleenp_YtMursleenPanel";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>